install.packages(c('devtools','ggplot2','Matching', 'MatchIt',
				   'party','PSAgraphics','rbounds','rpart'), 
				 repos='http://cran.r-project.org')
require(devtools)
install_github('multilevelPSA', 'jbryer')
install_github('TriMatch', 'jbryer')
#install_github('pisa', 'jbryer')

require(ggplot2)
require(multilevelPSA)
require(Matching)
require(MatchIt)
require(multilevelPSA)
require(party)
require(PSAgraphics)
require(granova)
require(rbound)
require(rpart)
require(TriMatch)

data(lindner)
data(lalonde, package='Matching')
data(nmes)
data(pisana)

table(lalonde$treat)

# lalonde.formu <- treat~age + I(age^2) + educ + I(educ^2) + black +
# 	hisp + married + nodegr + re74  + I(re74^2) + re75 + I(re75^2) +
# 	u74 + u75

lalonde.formu <- treat ~ age + educ  + black + hisp + married + nodegr + re74 + re75

glm1 <- glm(lalonde.formu, family=binomial, data=lalonde)

summary(glm1)

treefit <- rpart(lalonde.formu, data=lalonde)
print(treefit)
plot(treefit); text(treefit)

ps <- fitted(glm1)  # Propensity scores
Y  <- lalonde$re78  # Dependent variable, real earnings in 1978
Tr <- lalonde$treat # Treatment indicator

summary(ps)
boxplot(ps)
plot(density(ps))

psadf <- data.frame(ps, Y, Tr)
ggplot(psadf, aes(x=ps, group=Tr, color=factor(Tr))) + geom_density()

ggplot(psadf, aes(x=ps, y=Y, color=factor(Tr))) + geom_point()
ggplot(psadf, aes(x=ps, y=Y, color=factor(Tr))) + geom_point() + geom_smooth()

loess.plot(psadf[psadf$Y < 30000,]$ps, response=psadf[psadf$Y < 30000,]$Y, 
		   treatment=as.logical(psadf[psadf$Y < 30000,]$Tr))


# one-to-one matching with replacement (the "M=1" option).
# Estimating the treatment effect on the treated (the "estimand" option which defaults ATT).
rr <- Match(Y=Y, Tr=Tr, X=ps, M=1, ties=FALSE)
summary(rr) # The default estimate is ATT here
ls(rr)

length(rr$index.dropped)
matches <- cbind(Treat=rr$index.treated, Control=rr$index.control)
head(matches)
matches <- data.frame(Treat=lalonde[rr$index.treated,'re78'], Control=lalonde[rr$index.control,'re78'])
head(matches)
nrow(matches)
t.test(x=matches$Treat, y=matches$Control)

granova.ds(matches)
granovagg.ds(matches)

rr2 <- Matchby(Y=Y, Tr=Tr, X=ps, by=factor(lalonde$married))
summary(rr2)

rr.ate <- Match(Y=Y, Tr=Tr, X=ps, M=1, estimand='ATE')
summary(rr.ate) # Here the estimate is ATE


strata <- cut(ps, quantile(ps, seq(0, 1, 1/5)), include.lowest=TRUE, labels=letters[1:5])
table(strata)

strata10 <- cut(ps, quantile(ps, seq(0, 1, 1/10)), include.lowest=TRUE, labels=letters[1:10])
table(strata10)

psadf$Strata <- strata

ggplot(psadf, aes(x=ps, y=Y, color=Strata, shape=factor(Tr))) + geom_point(size=3)

describeBy(psadf$Y, group=list(psadf$Tr, psadf$Strata), mat=TRUE, skew=FALSE)

strata.tree <- treefit$where
length(strata.tree)
table(strata.tree)
table(strata.tree, lalonde$treat)
prop.table(table(strata.tree, lalonde$treat), 1) * 100

##### Checking Balance #########################################################

match.age <- data.frame(Treat=lalonde[rr$index.treated,'age'], 
						Control=lalonde[rr$index.control,'age'])
t.test(match.age$Treat, match.age$Control)

mb <- MatchBalance(treat~age + I(age^2) + educ + I(educ^2) + black +
						hisp + married + nodegr + re74  + I(re74^2) + re75 + I(re75^2) +
						u74 + u75, data=lalonde, match.out=rr, nboots=100)

box.psa(lalonde$age, lalonde$treat, strata, xlab="Strata", balance=FALSE)#, legend.xy=c(100,100))
cat.psa(lalonde$married, lalonde$treat, strata, xlab='Strata', balance=FALSE)

covars <- all.vars(lalonde.formu)
covars <- lalonde[,covars[2:length(covars)]]
cv.bal.psa(covars, lalonde$treat, ps, strata)

##### Phase II #################################################################

circ.psa(lalonde$re78, lalonde$treat, strata, revc=TRUE)

circ.psa(lalonde$re78, lalonde$treat, strata10, revc=TRUE)

circ.psa(lalonde$re78, lalonde$treat, strata.tree, revc=TRUE)

